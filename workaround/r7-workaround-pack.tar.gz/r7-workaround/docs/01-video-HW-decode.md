# 01 - HW Video Decode Dissection & Workaround

## TL;DR
- **Decoder WORKS:** Exynos MFC `/dev/video6` via `gst-droid` `droidvdec` Rank 257 decodes H.264/VP9 1080p60 proven on live YouTube.
- **Stutter cause:** Chromium (default browser) decodes `<video>` internally, no VA-API on Halium -> SW decode.
- Droidian official HW video since Halium 12 is via **Clapper / Celluloid**: *Tools like celluloid and clapper now use hardware video playback.*【5104874486019225029†L3-L7】
- **Blocker:** Clapper crashes at GL init.

## The 3 Walls (from sesi-16)

### Wall A - GL crash `Unable to interpret GL_VERSION string:`
- `droideglsink`, Clapper, Epiphany-WebKit all die before first frame.
- Phoc (compositor) has working Mali GL context, apps don't.
- Root: app EGL loads Mesa `/usr/lib/aarch64-linux-gnu/libEGL.so.1` instead of hybris wrapper `/usr/lib/aarch64-linux-gnu/libhybris/libEGL.so.1`. `glGetString(GL_VERSION)` returns NULL -> gstreamer asserts.
- Fix: force hybris EGL vendor.

### Wall B - No `linux-dmabuf`
- `phoc` on `HWCOMPOSER-1` backend doesn't advertise `zwp_linux_dmabuf_v1`.
- So `waylandsink` can't zero-copy import gralloc buffer.
- Workaround: use `droideglsink` (EGLImage path) once Wall A fixed, or SHM with stride fix.

### Wall C - SHM stride skew
- Only working display path `droidvdec ! videoconvert ! waylandsink` shows recognizable but diagonally-skewed image.
- MFC aligns stride to 128 or 256 bytes: 1920 -> 2048. Caps say 1920, real 2048. `videoconvert` misreads.
- `capssetter` to reinterpret stride breaks droid buffer pool -> 0 frames.
- `gst_droidvec_copy_plane` already handles stride, but we bypass it when using `videoconvert`.

## Immediate Workaround: Stride-fixed SHM pipeline

Tell GStreamer the real stride via caps:

```bash
gst-launch-1.0 souphttpsrc location="$URL" ! matroskademux ! vp9parse ! droidvdec ! \
  capssetter caps='video/x-raw,format=NV12,width=1920,height=1080,strides=(int)[2048\,1024],offset=(int)[0\,2097152]' ! \
  videoconvert ! waylandsink
```

For H.264:

```bash
gst-launch-1.0 souphttpsrc location="$URL" ! qtdemux ! h264parse ! droidvdec ! \
  'video/x-raw,format=NV12,width=1920,height=1080,stride=2048' ! videoconvert ! waylandsink
```

If `capssetter` breaks pool, try:

```bash
... droidvdec ! 'video/x-raw,format=NV12,width=1920,height=1080' ! videoconvert ! videoscale ! waylandsink
```

or use provided script `r7-yt-hw` which tries both.

## Proper Fix: Make Clapper's GL work

1. Verify hybris EGL precedence:
```bash
cat /etc/ld.so.conf.d/* | grep hybris
ldconfig -p | grep libEGL.so.1
ls -l /usr/lib/aarch64-linux-gnu/libhybris/
```

Should show:
```
/usr/lib/aarch64-linux-gnu/libhybris/libEGL.so.1 -> libhybris/common/libEGL.so.1
```

If not, install `files/etc/ld.so.conf.d/00-hybris-r7.conf` and `ldconfig`.

2. Set environment for apps (not just phoc):
```bash
# /etc/environment.d/99-r7-egl.conf
EGL_PLATFORM=hwcomposer
HYBRIS_EGLPLATFORM=hwcomposer
GBM_BACKEND=droid
__EGL_VENDOR_LIBRARY_FILENAMES=/usr/lib/aarch64-linux-gnu/libhybris/egl/vendors.d/hybris.json:/usr/share/glvnd/egl_vendor.d/50_mesa.json
```

3. Launch with debug:
```bash
G_MESSAGES_DEBUG=all GST_DEBUG=3 clapper 2>&1 | grep -i -E 'gl_version|egl|droidegl'
```

When fixed, `droideglsink` will not crash and `gst-inspect-1.0 droideglsink` shows `GL context: Mali-G72`.

4. Rebuild adaptation package: compare `crownlte` device repo's `hybris.conf`, `egl/`, `gbm/` configs. Crownlte uses `libhybris-egl -C wayland` wrapper.

## Sharp edges logged

- `droidvdec` needs pool-proposing sink: `fakesink`, `jpegenc`, `decodebin` -> "No valid frames"
- Failed teardown leaves `gst-launch-1.0` spinning in segv handler, pegging core, hangs SSH: always `pkill -9 -x gst-launch-1.0`
- `loadavg ~11` is misleading (D-state tasks waiting on MFC), CPU actually idle

## Next kernel work (not in workaround)

- Enable `CONFIG_DRM` dmabuf export for phoc `linux-dmabuf` (if possible on 4.9 downstream)
- Or patch `phoc` to advertise `zwp_linux_dmabuf_v1` even without gbm dmabuf, using hybris gralloc import
