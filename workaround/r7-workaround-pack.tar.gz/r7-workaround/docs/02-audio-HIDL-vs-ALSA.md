# 02 - Audio Dissection & Workaround

## Root cause (proven on-device)

- `pulseaudio.service` stuck `activating`
- `module-droid-card` (64-bit passthrough) loads `/vendor/lib64/hw/audio.primary.default.so` (11KB stub) -> `droid-sink: Open output stream "primary-out"->"Speaker"` then **SEGFAULT**
- Real HAL: `/vendor/lib/hw/audio.primary.exynos9810.so` (98KB) **32-bit only**
- 64-bit process cannot dlopen 32-bit .so -> needs HIDL indirection
- HIDL service `vendor.audio-hal` should be 32-bit `android.hardware.audio@6.0-service` serving HAL over binder, then `pulseaudio-modules-droid-hidl` talks to it
- Service not running: `ctl.start vendor.audio-hal` -> err `0x20` (NO_SUCH_SERVICE or dependency failure)

UBports docs describe the inverse default: **Audio HAL process is disabled by default as it's expected that pulseaudio-modules-droid will be able to use Audio HAL directly. Modify the file by commenting the sections which mentions `audio-hal`.**【2915628016177476172†L22-L25】 On Samsung Exynos you must **re-enable** it.

Normal Hybris case is: **In general in Hybris environment just install pulseaudio-modules-droid package and sound will work. Make sure you have the following line in your `/etc/pulse/default.pa`: `load-module module-droid-card`**【6724743064709098843†L12-L16】 - that assumes 64-bit HAL exists, which r7 does NOT have.

## Workaround A - ALSA direct (immediate, 2 min)

Bypass Android HAL entirely, use kernel ALSA. `/dev/snd/*` nodes exist, kernel driver `snd_soc_samsung` is fine.

Pros: instant speaker/headphone, YouTube works
Cons: no call routing, no mic routing via Android, no Bluetooth audio

Files:
- `files/etc/pulse/default.pa.d/99-r7-alsa-workaround.pa`

Install:
```bash
sudo cp 99-r7-alsa-workaround.pa /etc/pulse/default.pa.d/
pulseaudio -k; pulseaudio --start
pactl list sinks
```

Test direct ALSA (bypass Pulse):
```bash
aplay -l
# expect: card 0: r7 [r7-snd], device 0: ...
cat /proc/asound/cards
aplay /usr/share/sounds/alsa/Front_Center.wav -D hw:0,0
# if busy:
sudo fuser -v /dev/snd/*
```

If `hw:0,0` fails, try `hw:0,1` (Samsung often has `deep-buffer` as 0,1) or `plughw:0,0`.

UCM: Samsung needs UCM for jack detection. Copy crownlte UCM as baseline:
```bash
sudo mkdir -p /usr/share/alsa/ucm2/Exynos9810
# copy from https://github.com/droidian-devices/adaptation-crownlte/tree/droidian/alsa-ucm
```

## Workaround B - Proper HIDL enable (30-60 min debug)

Goal: get 32-bit `vendor.audio-hal` running.

1. Inspect inside container:
```bash
lxc-attach -n android -- getprop | grep audio
lxc-attach -n android -- ps -A | grep -E 'audioserver|audio-hal|vndservicemanager'
lxc-attach -n android -- ls -l /vendor/bin/hw/android.hardware.audio*
lxc-attach -n android -- ls -l /vendor/etc/init/*audio*.rc
```

2. Check RC file:
```bash
lxc-attach -n android -- cat /vendor/etc/init/android.hardware.audio@6.0-service.rc
```
Look for:
```
service vendor.audio-hal-6-0 /vendor/bin/hw/android.hardware.audio@6.0-service
    class hal
    user audioserver
    ...
    disabled   # <- remove this
    oneshot    # <- remove if present for hal service
```

If `disabled` present, that's the blocker. Remove it:
```bash
lxc-attach -n android -- mount -o remount,rw /vendor
lxc-attach -n android -- sed -i '/^[^#]*disabled/d' /vendor/etc/init/android.hardware.audio@6.0-service.rc
```

3. Dependencies:
- `vndservicemanager` must be running: `getprop init.svc.vndservicemanager` -> running
- `audioserver` user must exist in container
- SELinux: `getenforce` should be `Permissive` (Droidian Halium sets permissive)
- Permissions: `ls -lZ /dev/snd/pcmC0D0p` -> should be `u:object_r:audio_device:s0`

4. Logs:
```bash
lxc-attach -n android -- logcat -b all -d | grep -i audio | tail -n 100
dmesg | grep -iE 'avc.*denied|audio' | tail
```

Common Samsung errors:
- `CANNOT LINK EXECUTABLE: library "libaudiohal.so" not found` -> need `LD_LIBRARY_PATH=/vendor/lib:/vendor/lib/hw`
- `Failed to open audio primary` -> stub loaded, need to force exynos9810: symlink `audio.primary.default.so -> audio.primary.exynos9810.so` in 32-bit dir (not 64-bit)

5. After service starts:
```bash
# on Droidian host
pactl unload-module module-alsa-card 2>/dev/null; true
sudo rm /etc/pulse/default.pa.d/99-r7-alsa-workaround.pa
pulseaudio -k; pulseaudio --start
pactl load-module module-droid-card-6.0
journalctl --user -u pulseaudio -n 100 --no-pager | grep droid
```

You should see:
```
droid-card: Found 2 audio HAL modules
droid-sink: Open output stream primary-out -> Speaker (success, no segfault)
```

6. If it still segfaults but via HIDL, you are still loading passthrough. Ensure `/etc/pulse/droid.pa` uses `module-droid-card-6.0` not `module-droid-card` (passthrough). Droidian 101 uses `module-droid-card-7.0` for API33.

## Safety note from sesi-15b

Poking audio HAL crashed phone once (auto-recovered). Do HIDL edits with SSH `catch-loop.sh` ready: it hammers SSH and masks offending unit if bootloop.

Always keep a working ALSA config backup so you can `ssh` in and `pulseaudio -k` even if droid module crashes.

## Adaptation package TODO

Bake into `droidian-device-r7` .deb:
- `99-r7-nopanic.conf` (already)
- `99-block-fimc-cam.rules` (already)
- `00-hybris-r7.conf` + `99-r7-egl.conf`
- ALSA UCM for exynos9810 + fallback `default.pa.d` that tries HIDL first, falls back to ALSA if `vendor.audio-hal` not found (use `.ifexists module-droid-card-6.0.so`)
