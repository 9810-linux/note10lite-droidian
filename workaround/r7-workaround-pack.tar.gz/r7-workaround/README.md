# Galaxy Note 10 Lite (SM-N770F, r7) - Droidian Workarounds
## HW Video Accel Stutter + Audio Not Working

**Device:** Exynos 9810, Mali-G72, Kernel 4.9.191-samsung-r7, Droidian 101 (API 33 / Halium 13), Phosh

**Status before workaround:**
- Display, touch, WiFi, Phosh OK (D2 achieved)
- GPU accel works (`/dev/mali0`, `OpenGL ES 3.2 v1.r38p1` via libhybris)
- **Video:** HW decoder WORKS (`/dev/video6 s5p-mfc-dec0` via `droidvdec` decodes H.264+VP9 1080p60) but stutters because Chromium SW-decodes and Clapper crashes with `Unable to interpret GL_VERSION string:`
- **Audio:** No sinks. `pulseaudio` crash-loops. `audio.primary.exynos9810.so` is 32-bit only in `/vendor/lib/hw/`, while 64-bit `/vendor/lib64/hw/audio.primary.default.so` is 11KB stub -> segfault. Needs HIDL service `vendor.audio-hal` which is not running.

This pack gives you **immediate workarounds** + **proper fix path**.

### Quick install (on phone via SSH)

```bash
# from your host where you downloaded this folder
scp -r files/* droidian@10.15.19.82:/tmp/r7-files/
ssh droidian@10.15.19.82

# ALSA immediate audio (5 sec fix)
sudo cp /tmp/r7-files/etc/pulse/default.pa.d/99-r7-alsa-workaround.pa /etc/pulse/default.pa.d/
pulseaudio -k; pulseaudio --start
pactl list short sinks   # should show primary-out
aplay /usr/share/sounds/alsa/Front_Center.wav -D hw:0,0

# Video stride fix + Clapper env
sudo cp /tmp/r7-files/etc/ld.so.conf.d/00-hybris-r7.conf /etc/ld.so.conf.d/
sudo cp /tmp/r7-files/etc/environment.d/99-r7-egl.conf /etc/environment.d/
sudo cp /tmp/r7-files/usr/local/bin/r7-yt-hw /usr/local/bin/ && chmod +x /usr/local/bin/r7-yt-hw
sudo cp /tmp/r7-files/usr/share/applications/clapper-r7.desktop /usr/share/applications/
sudo ldconfig
```

### Contents

- `docs/01-video-HW-decode.md` - Full dissection of 3 walls blocking video display
- `docs/02-audio-HIDL-vs-ALSA.md` - Why 32-bit HAL fails and two workarounds
- `files/` - Drop-in configs ready to copy to rootfs
- `../WORKAROUND.md` - Single-file version for GitHub / XDA post

> **Persistence warning:** All files live in rootfs LV. They are lost on `rootfs.img` reflash. Bake into adaptation .deb later (see TODO in doc).

### Test matrix

| Test | Expected after workaround A |
|------|-----------------------------|
| `gst-launch-1.0 ... droidvdec ! ... waylandsink` | Video visible, no diagonal skew |
| `r7-yt-hw https://youtube.com/watch?v=...` | 1080p VP9 plays, CPU ~15% not 90% |
| `clapper-r7` (from app drawer) | No GL_VERSION crash, uses droideglsink |
| `aplay -D hw:0,0` | Sound from speaker |
| YouTube in Clapper | Video + Audio |

See full docs for proper HIDL fix (call audio, mic, bluetooth routing).
