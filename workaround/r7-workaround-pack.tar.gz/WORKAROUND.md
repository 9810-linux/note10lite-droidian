# SM-N770F r7 - Droidian Workaround Pack (Video Stutter + No Audio)

> Copy of README + docs merged into single markdown for XDA / GitHub issue

## Problem Summary

**Video:** HW decoder works (`s5p-mfc-dec0` via `droidvdec` decodes VP9/H264 1080p60) but default browser Chromium SW-decodes. Clapper should use HW via `droideglsink` per Droidian official: *Tools like celluloid and clapper now use hardware video playback.*【5104874486019225029†L3-L7】 but crashes `Unable to interpret GL_VERSION string:` because app EGL loads Mesa not hybris.

**Audio:** No sinks. `audio.primary.exynos9810.so` is 32-bit only in `/vendor/lib/hw/`, 64-bit stub in `/vendor/lib64/hw/audio.primary.default.so` segfaults. Must use HIDL `vendor.audio-hal` service, which is currently disabled. This matches known Halium pattern where **Audio HAL process is disabled by default as it's expected that pulseaudio-modules-droid will be able to use Audio HAL directly. Modify the file by commenting the sections which mentions `audio-hal`.**【2915628016177476172†L22-L25】 - for r7 you need the opposite: enable it. Normal case docs say **In general in Hybris environment just install pulseaudio-modules-droid package and sound will work. Make sure you have the following line in your `/etc/pulse/default.pa`: `load-module module-droid-card`**【6724743064709098843†L12-L16】 which fails here because HAL is 32-bit only.

## Immediate Fix (2 minutes)

```bash
ssh droidian@10.15.19.82
sudo cp 99-r7-alsa-workaround.pa /etc/pulse/default.pa.d/
pulseaudio -k; pulseaudio --start; pactl list sinks
aplay -D hw:0,0 /usr/share/sounds/alsa/Front_Center.wav
```

Now you have speaker. For video:

```bash
sudo cp 00-hybris-r7.conf /etc/ld.so.conf.d/ && sudo ldconfig
sudo cp 99-r7-egl.conf /etc/environment.d/
sudo cp r7-yt-hw /usr/local/bin/ && chmod +x /usr/local/bin/r7-yt-hw
r7-yt-hw https://www.youtube.com/watch?v=jfKfPfyJRdk
```

## Files in this pack

- `files/etc/pulse/default.pa.d/99-r7-alsa-workaround.pa` - ALSA sink fallback
- `files/etc/ld.so.conf.d/00-hybris-r7.conf` - Force hybris libEGL precedence
- `files/etc/environment.d/99-r7-egl.conf` - EGL_PLATFORM=hwcomposer for apps
- `files/etc/udev/rules.d/99-block-fimc-cam.rules` - Block fimc-is panic (browser WebRTC probe)
- `files/etc/sysctl.d/99-r7-nopanic.conf` - kernel.panic_on_oops=0
- `files/usr/local/bin/r7-yt-hw` - YouTube HW play with stride fix
- `files/usr/local/bin/r7-audio-debug` / `r7-video-debug` - diagnostics
- `files/usr/share/applications/clapper-r7.desktop` - Clapper with env forced

## Proper HIDL Audio Fix Path (to replace ALSA)

1. `lxc-attach -n android -- cat /vendor/etc/init/android.hardware.audio@6.0-service.rc` check `disabled`
2. `mount -o remount,rw /vendor && sed -i '/disabled/d' ...`
3. Ensure `vndservicemanager` running, `getenforce` Permissive, `ls -lZ /dev/snd`
4. Restart container `systemctl restart lxc@android`
5. Host: `pactl load-module module-droid-card-6.0` should show success not segfault

## Proper Video Fix Path

1. Verify `ldconfig -p | grep libEGL` points to hybris first
2. `G_MESSAGES_DEBUG=all clapper` should no longer show `Unable to interpret GL_VERSION`
3. `droideglsink` uses `EGLImage` from gralloc -> stride handled, no skew
4. Once working, uninstall stride workaround, use plain Clapper

## Persistence

All fixes live in rootfs LV `/dev/droidian/droidian-rootfs`. Reflashing `rootfs.img` wipes them. TODO: bake into `droidian-device-r7` .deb adaptation package with first-boot hook.

## References

- Droidian Week 36 2023 HW video support note
- UBports audio-hal disabled default note
- postmarketOS pulseaudio-modules-droid note
